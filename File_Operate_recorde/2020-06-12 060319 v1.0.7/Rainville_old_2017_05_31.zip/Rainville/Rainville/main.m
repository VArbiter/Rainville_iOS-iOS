//
//  main.m
//  Rainville
//
//  Created by 冯明庆 on 16/12/7.
//  Copyright © 2016年 冯明庆. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CCAppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([CCAppDelegate class]));
    }
}
