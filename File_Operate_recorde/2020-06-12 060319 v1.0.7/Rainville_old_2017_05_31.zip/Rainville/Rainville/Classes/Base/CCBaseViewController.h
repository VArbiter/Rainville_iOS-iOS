//
//  CCBaseViewController.h
//  Rainville
//
//  Created by 冯明庆 on 16/12/12.
//  Copyright © 2016年 冯明庆. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CCBaseViewController : UIViewController

@property (nonatomic , strong , readonly) NSString * stringControllerName ;

@end
