//
//  CCMainViewController.h
//  Rainville
//
//  Created by 冯明庆 on 16/12/12.
//  Copyright © 2016年 冯明庆. All rights reserved.
//

#import "CCBaseViewController.h"

@interface CCMainViewController : CCBaseViewController

@end
